National Land Cover Database (NLCD) Tiled Data Distribution SYstem (TDDS) Zipfile Content Readme

Table of Contents


INTRODUCTION
Process Description
Part 1: Data Specification
PART 2: TILED DATA DISTRIBUTION SYSTEM (TDDS) - ORTHOIMAGERY INFORMATION
Part 3: FILE NAMING CONVENTION
PART 4: CONTENTS OF ZIPFILE
PART 5: DISTRIBUTION INFORMATION
Part 6: Resource Information

Introduction
The National Land Cover Database 2011 (NLCD2011) USFS percent tree canopy product was produced through a cooperative project conducted by the Multi-Resolution Land Characteristics (MRLC) Consortium (www.mrlc.gov). The MRLC Consortium is a partnership of federal agencies, consisting of the U.S. Geological Survey, the National Oceanic and Atmospheric Administration, the U.S. Environmental Protection Agency, the U.S. Department of Agriculture (USDA) National Agricultural Statistics Service, the U.S. Forest Service, the National Park Service, the U.S. Fish and Wildlife Service, the Bureau of Land Management, NASA, and the U.S. Army Corps of Engineers. One of the primary goals of the project was to generate current, consistent, and seamless national land cover, percent tree canopy, and percent impervious cover at medium spatial resolution. This product is the cartographic version of the NLCD2011 percent tree canopy cover dataset for CONUS at medium spatial resolution (30 m). It was produced by the USDA Forest Service Remote Sensing Applications Center (RSAC). Tree canopy values range from 0 to 100 percent. The analytic tree canopy layer was produced using a Random Forests� regression algorithm. The cartographic product is a filtered version of the regression algorithm output. 


Process Description
   Creation of NLCD2011 USFS Percent Tree Canopy, cartographic version. The cartographic version of the percent tree canopy product is a filtered version of the corresponding analytic product, in which values less than a calculated uncertainty have been set to zero. In essence, the filtering process reduces errors of commission by eliminating values that are not significantly different from zero. A threshold value was determined for each of 68 geographic zones using data from 500 runs of the Random Forest� algorithm on bootstrap samples. From these data, t-statistics were calculated. For each zone, the t-statistic at the 95th interval was selected as the threshold value. Threshold values ranged from 0.5 to 1.6. To create the cartographic layer, the product of the t-statistic threshold value and the standard error from the analytic layer was compared to the analytic percent tree canopy value. If the threshold-error product was greater than the percent tree canopy, the tree canopy value for that pixel was set to zero in the cartographic layer; otherwise, the percent tree canopy from the analytic layer was used. 


PART 1: Data Specifications and Products


	Resolution:      	one Arc Second (~30 meter)
  	Data type:      	GeoTIFF
  	Projection:  		Albers Conical Equal Area
  	Datum:       		NAD83
  	

	NLCD 2011 - Tree Canopy  - 2011 Edition includes data for Conterminous U.S..  
	

PART 2: TILED DATA DISTRIBUTION SYSTEM (TDDS) - NLCD INFORMATION

Tiled Data Distribution System (TDDS) is a means to access pre-packaged data.  Each 2001 NLCD product are cut to 3 x 3 degree tiles and zipped for online download.  The zip bundles contain the product image and associated files, an overall coverage shapefile, metadata, color table file, appendix of scene listings, and readme.  The data is available for download thru The National Map viewer and MRLC viewer.  (http://viewer.nationalmap.gov/viewer/ and http://gisdata.usgs.gov/website/mrlc/viewer.htm)

Part 3: FILE NAMING CONVENTION

Each tile is cut to a 3 x 3 degree area.  The naming convention for each tile is the NLCD product and lower right corner coordinate. 


The file naming convention is:
	
        NLCDFFFF_NNN_aaaaaa

		NLCD      =  National Land Cover Database
		FFFF      =  Project Year (2011)
                NNN       =  Product type (CAN = Canopy)
		aaaaaa    =  Lower right corner coordinate (N24W078) 		


  	Example: NLCD2011_CAN_N24W078.zip 

			NLCD     =  National Land Cover Database
	 		2011     =  Project year 2011
		      	CAN      =  Canopy product
                        N24W078  =  Tile extent starts at the lower right corner coodinate of N 					24 and W 78. The data covers an area within N 24, N 27, 
					W 78, W 81  
                        			           

PART 4: CONTENTS OF ZIPFILE

	
	.tif  	 =  Geotiff image
	.tfw	 =  World file for full resolution Geotiff image
	.aux.xm l=  diplay info
	.prj	 =  Projection File
	.jpg	 =  Lossy compressed image
	.jpw     =  World file for lossy compressed image
	.xml     =  FGDC Metadata file 
	.htm     =  HTML format FGDC metadata file suitable for reading and printing
	.vat.dbf =  Color table information
	Shapefile
	 (.dbf, .prj, .sbn, .sbx, .shp, .shx)
		=  The shapefile (consisting of 6 files) represents the overall 3 x 3 degree GRID 
	NLCDReadme2011_CAN_2011Edition.txt 
		=  The readme text file
	Appendix
		=  List of Landsat scenes and scene dates by path/row used in this project


PART 5: DISTRIBUTION INFORMATION

	Access points (i.e. map interface) can be found at:
		
		http://viewer.nationalmap.gov/viewer/ and http://gisdata.usgs.gov/website/mrlc/viewer.htm
	
	To acquire entire datasets via Bulk Data Distribution, they can be found at:
	
		http://www.mrlc.gov/


Part 6: Resource Information

Information concerning the Multi-Resolution Land Characteristics Consortium  (MRLC), data info, and refernces can be found at:
	
		http://www.mrlc.gov/



Disclaimer:  Any use of trade, product, or firm names is for descriptive 
purposes only and does not imply endorsement by the U. S. Government.    


Readme Publication Date:  May 2014


